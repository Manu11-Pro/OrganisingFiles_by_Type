# 📁OrganisingFiles_by_Type
- 📄 This repo features File Organising by Type of Files!.
- 📄 This repo uses Python to Organise Files so that users can care about doing stuff they want to instead of the tedious new_folder,copy,cut,paste.
- 📄 It is also a good way to not loose your files in the messy file heapes!

# Installation
The installation of OrganisingFiles_by_Type is very simple :  
- Open a clean Terminal
- Type :
- ``` bash
  pip install OrganisingFiles_by_Type 
  ```
- The Installation should start and the package should be downloaded in some time.
- Type :
- ``` bash 
  organise 
  ``` 
  in Terminal to start organising!

# Organising into Types!
  ## 📸 Images
  - png
  - jpg
  - jpeg
  - and more coming...

  ## 📄 Documents
  - txt
  - pdf
  - docx
  - ods
  - xlsx
  - and more coming...

  ## 📹 Videos
  - mp4
  - mov
  - ogv
  - and more coming...

  ## 🔊 Audio 
  - mp3
  - wav
  - and more coming...

  ## 🧊 3D
  - obj
  - stl
  - amf
  - and more coming...
  
# Optimization

- Optimised the core logic to improve performance

  ## Change
  - Removed heaps of If statements which causes performance decrease.
  - Instead Added dictionary lookup mapping which increased performance!
  - Change :
      If statements :  ~0.2910s
      Dictionary    :  ~0.2007s

      A ~31% Increase in Performance!